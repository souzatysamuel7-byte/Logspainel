"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

type Log = {
  id: string
  admin: string
  jogador: string
  acao: string
  data: string
  videoUrl: string
  servidor: string
}

export default function AdminPanel() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [selectedServer, setSelectedServer] = useState<string | null>(null)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [logs, setLogs] = useState<Log[]>([])
  const [filteredLogs, setFilteredLogs] = useState<Log[]>([])
  const [filterAdmin, setFilterAdmin] = useState("")
  const [filterJogador, setFilterJogador] = useState("")
  const [filterAcao, setFilterAcao] = useState("")
  const [currentAdmin, setCurrentAdmin] = useState("")

  // Form states
  const [newLogJogador, setNewLogJogador] = useState("")
  const [newLogAcao, setNewLogAcao] = useState("")
  const [newLogVideo, setNewLogVideo] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [selectedVideo, setSelectedVideo] = useState("")

  useEffect(() => {
    const savedUser = localStorage.getItem("adminUser")
    const savedLogs = localStorage.getItem("adminLogs")

    if (savedUser) {
      setIsLoggedIn(true)
      setCurrentAdmin(savedUser)
    }

    if (savedLogs) {
      const parsedLogs = JSON.parse(savedLogs)
      setLogs(parsedLogs)
      setFilteredLogs(parsedLogs)
    }
  }, [])

  useEffect(() => {
    let filtered = logs.filter((log) => log.servidor === selectedServer)

    if (filterAdmin) {
      filtered = filtered.filter((log) => log.admin.toLowerCase().includes(filterAdmin.toLowerCase()))
    }

    if (filterJogador) {
      filtered = filtered.filter((log) => log.jogador.toLowerCase().includes(filterJogador.toLowerCase()))
    }

    if (filterAcao) {
      filtered = filtered.filter((log) => log.acao.toLowerCase().includes(filterAcao.toLowerCase()))
    }

    setFilteredLogs(filtered)
  }, [logs, selectedServer, filterAdmin, filterJogador, filterAcao])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    if (username && password) {
      localStorage.setItem("adminUser", username)
      setCurrentAdmin(username)
      setIsLoggedIn(true)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("adminUser")
    setIsLoggedIn(false)
    setSelectedServer(null)
    setUsername("")
    setPassword("")
    setCurrentAdmin("")
  }

  const handleAddLog = () => {
    if (newLogJogador && newLogAcao && selectedServer) {
      const newLog: Log = {
        id: Date.now().toString(),
        admin: currentAdmin,
        jogador: newLogJogador,
        acao: newLogAcao,
        data: new Date().toLocaleString("pt-BR"),
        videoUrl: newLogVideo,
        servidor: selectedServer,
      }

      const updatedLogs = [...logs, newLog]
      setLogs(updatedLogs)
      localStorage.setItem("adminLogs", JSON.stringify(updatedLogs))

      setNewLogJogador("")
      setNewLogAcao("")
      setNewLogVideo("")
      setShowAddDialog(false)
    }
  }

  const handleDeleteLog = (id: string) => {
    const updatedLogs = logs.filter((log) => log.id !== id)
    setLogs(updatedLogs)
    localStorage.setItem("adminLogs", JSON.stringify(updatedLogs))
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const getActionColor = (acao: string) => {
    switch (acao.toLowerCase()) {
      case "ban":
        return "destructive"
      case "kick":
        return "destructive"
      case "jail":
        return "default"
      case "prisão administrativa":
        return "secondary"
      case "advertência":
        return "outline"
      default:
        return "default"
    }
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-purple-950 to-black flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 bg-black/80 border-purple-700">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 mb-2">
              Shadow Roleplay
            </h1>
            <p className="text-gray-400">Administração</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="username" className="text-gray-300">
                Nome do Admin
              </Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-gray-900 border-purple-700 text-white mt-1"
                placeholder="Digite seu nome"
                required
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-gray-300">
                Senha
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-gray-900 border-purple-700 text-white mt-1"
                placeholder="Digite sua senha"
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              Entrar
            </Button>
          </form>
        </Card>
      </div>
    )
  }

  if (!selectedServer) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-purple-950 to-black flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 bg-black/80 border-purple-700">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 mb-2">
              Selecione o Servidor
            </h1>
            <p className="text-gray-400">Bem-vindo, {currentAdmin}</p>
          </div>

          <div className="space-y-4">
            <Button
              onClick={() => setSelectedServer("servidor1")}
              className="w-full h-16 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-lg"
            >
              Servidor 1
            </Button>

            <Button
              onClick={() => setSelectedServer("servidor2")}
              className="w-full h-16 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-lg"
            >
              Servidor 2
            </Button>

            <Button
              onClick={handleLogout}
              variant="outline"
              className="w-full border-purple-700 text-purple-400 hover:bg-purple-950 bg-transparent"
            >
              Sair
            </Button>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-purple-950 to-black p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">
              Shadow Roleplay
            </h1>
            <p className="text-gray-400">
              Painel Administrativo - {selectedServer === "servidor1" ? "Servidor 1" : "Servidor 2"}
            </p>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={() => setSelectedServer(null)}
              variant="outline"
              className="border-purple-700 text-purple-400"
            >
              Trocar Servidor
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-purple-700 text-purple-400 bg-transparent"
            >
              Sair
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="p-4 mb-6 bg-black/80 border-purple-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label className="text-gray-300">Filtrar por Admin</Label>
              <Input
                value={filterAdmin}
                onChange={(e) => setFilterAdmin(e.target.value)}
                placeholder="Nome do admin"
                className="bg-gray-900 border-purple-700 text-white mt-1"
              />
            </div>

            <div>
              <Label className="text-gray-300">Filtrar por Jogador</Label>
              <Input
                value={filterJogador}
                onChange={(e) => setFilterJogador(e.target.value)}
                placeholder="Nome do jogador"
                className="bg-gray-900 border-purple-700 text-white mt-1"
              />
            </div>

            <div>
              <Label className="text-gray-300">Filtrar por Ação</Label>
              <Input
                value={filterAcao}
                onChange={(e) => setFilterAcao(e.target.value)}
                placeholder="Tipo de ação"
                className="bg-gray-900 border-purple-700 text-white mt-1"
              />
            </div>
          </div>
        </Card>

        {/* Add Log Button */}
        <div className="mb-6">
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button className="w-full md:w-auto bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                + Adicionar Novo Log
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black border-purple-700">
              <DialogHeader>
                <DialogTitle className="text-white">Adicionar Novo Log</DialogTitle>
              </DialogHeader>

              <div className="space-y-4">
                <div>
                  <Label className="text-gray-300">Jogador</Label>
                  <Input
                    value={newLogJogador}
                    onChange={(e) => setNewLogJogador(e.target.value)}
                    placeholder="Nome do jogador"
                    className="bg-gray-900 border-purple-700 text-white mt-1"
                  />
                </div>

                <div>
                  <Label className="text-gray-300">Ação</Label>
                  <Select value={newLogAcao} onValueChange={setNewLogAcao}>
                    <SelectTrigger className="bg-gray-900 border-purple-700 text-white">
                      <SelectValue placeholder="Selecione a ação" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-900 border-purple-700">
                      <SelectItem value="Ban">Ban</SelectItem>
                      <SelectItem value="Kick">Kick</SelectItem>
                      <SelectItem value="Jail">Jail</SelectItem>
                      <SelectItem value="Prisão Administrativa">Prisão Administrativa</SelectItem>
                      <SelectItem value="Advertência">Advertência</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-gray-300">URL do Vídeo (Prova)</Label>
                  <Input
                    value={newLogVideo}
                    onChange={(e) => setNewLogVideo(e.target.value)}
                    placeholder="https://exemplo.com/video.mp4"
                    className="bg-gray-900 border-purple-700 text-white mt-1"
                  />
                </div>

                <Button onClick={handleAddLog} className="w-full bg-gradient-to-r from-purple-600 to-blue-600">
                  Adicionar Log
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Logs List */}
        <div className="space-y-4">
          {filteredLogs.length === 0 ? (
            <Card className="p-8 bg-black/80 border-purple-700 text-center">
              <p className="text-gray-400">Nenhum log encontrado para este servidor.</p>
            </Card>
          ) : (
            filteredLogs.map((log) => (
              <Card
                key={log.id}
                className="p-6 bg-black/80 border-purple-700 hover:border-purple-500 transition-colors"
              >
                <div className="flex flex-col md:flex-row gap-4">
                  {/* Avatar */}
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center text-white font-bold text-xl">
                      {getInitials(log.admin)}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-purple-400 font-semibold">{log.admin}</span>
                      <Badge variant="outline" className="border-purple-700 text-purple-300">
                        Administrador
                      </Badge>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-gray-300">
                      <span>aplicou</span>
                      <Badge variant={getActionColor(log.acao)}>{log.acao}</Badge>
                      <span>em</span>
                      <span className="text-blue-400 font-semibold">{log.jogador}</span>
                    </div>

                    <p className="text-gray-500 text-sm">{log.data}</p>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col md:flex-row gap-2">
                    {log.videoUrl && (
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            className="border-purple-700 text-purple-400 hover:bg-purple-950 bg-transparent"
                            onClick={() => setSelectedVideo(log.videoUrl)}
                          >
                            Ver Prova
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-black border-purple-700 max-w-3xl">
                          <DialogHeader>
                            <DialogTitle className="text-white">Prova em Vídeo</DialogTitle>
                          </DialogHeader>
                          <video controls className="w-full rounded-lg" src={log.videoUrl}>
                            Seu navegador não suporta vídeos.
                          </video>
                        </DialogContent>
                      </Dialog>
                    )}

                    <Button variant="destructive" onClick={() => handleDeleteLog(log.id)}>
                      Excluir
                    </Button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
